'use strict';

// Configure the main application module.
var loginApp = angular.module('loginApp', ['ui.router', 'ui.bootstrap'])
/*Constants regarding user login defined here*/
	.constant('USER_ROLES', {
		all : '*',
		admin : 'admin',
		editor : 'editor',
		guest : 'guest'
	}).constant('AUTH_EVENTS', {
		loginSuccess : 'auth-login-success',
		loginFailed : 'auth-login-failed',
		logoutSuccess : 'auth-logout-success',
		sessionTimeout : 'auth-session-timeout',
		notAuthenticated : 'auth-not-authenticated',
		notAuthorized : 'auth-not-authorized'
	})
	/* Adding the auth interceptor here, to check every $http request*/
	.config(function ($httpProvider) {
		$httpProvider.interceptors.push([
			'$injector',
			function ($injector) {
				return $injector.get('AuthInterceptor');
			}
		]);
	})
	.controller('patientCtrl',['$scope',function ($scope) {
		$scope.logoIcon ='UTD.png';
		$scope.patientLast = "Cassidy";
		$scope.patientFirst = "George";
		$scope.patientBday ="March 13, 1944";

	}])

	.controller('navCtrl',['$scope', function($scope) {
		$scope.categories = [
			{"id": 0, "name": "Welcome", "icon": "glyphicon-home"},
			{"id": 1, "name": "Chart", "icon": "glyphicon-stats"},
			{"id": 2, "name": "Message", "icon": "glyphicon-envelope"},
			{"id": 3, "name": "Form", "icon": "glyphicon-file"},
			{"id": 4, "name": "Prescriptions", "icon": "glyphicon-link"},
			{"id": 5, "name": "Appointment", "icon": "glyphicon-calendar"},
			{"id": 6, "name": "Billing", "icon": "glyphicon-usd"}
		];
	}]);