angular
	.module('customize', ['colorpicker.module'])
	.controller('custController', function($scope) {
		
		$scope.saveData = function() {
			var lessText = "@bodyCol: orange;\n\nbody {\n\tbackground: @bodyCol;\n}";
			var lessFile = new Blob([lessText], {type: "text/css;charset=utf-8"});
			saveAs(lessFile, "styles.less");
		};

	});
