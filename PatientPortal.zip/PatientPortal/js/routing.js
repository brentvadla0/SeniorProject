angular.module('loginApp').config(['$stateProvider', '$urlRouterProvider', 'USER_ROLES',
    function($stateProvider, $urlRouterProvider, USER_ROLES) {

        // For any unmatched url, redirect to /
        $urlRouterProvider.otherwise("/");

        // Now set up the states
        $stateProvider
        // Home states
            .state('home', {
                url: "/",
                templateUrl: "templates/home.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            // Welcome
            .state('home.welcome', {
                url: "/welcome",
                templateUrl: "templates/welcome.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            // chart
            .state('home.chart', {
                url: "/chart",
                templateUrl: "templates/chart.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            // message
            .state('home.message', {
                url: "/message",
                templateUrl: "templates/message.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            // form
            .state('home.form', {
                url: "/form",
                templateUrl: "templates/form.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            // prescription
            .state('home.prescription', {
                url: "/prescription",
                templateUrl: "templates/prescription.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            // appointmnet
            .state('home.appointment', {
                url: "/appointment",
                templateUrl: "templates/appointment.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            //billing
            .state('home.billing', {
                url: "/billing",
                templateUrl: "templates/billing.html",
                data: {
                    authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
                }
            })
            // logout
            .state('logout',{
                url:"/",
                templateUrl: "index.html"
            })
        ;
    }]);