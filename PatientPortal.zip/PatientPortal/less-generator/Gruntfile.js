/**
 * Created by VqP on 4/6/2017.
 */
module.exports = function(grunt) {

    grunt.initConfig({


        connect: {
            server: {
                options: {
                    port: 9500,
                    base: ".",
                    keepalive: true,
                    open: {
                        target: 'http://localhost:9500/'
                    }
                }
            }
        },
        less: {
            development: {
                options: {
                    compress: true
                },
                files: {
                    "../css/styles.css": "less/default.less"
                }
            },
        }
    });
    grunt.loadNpmTasks('grunt-contrib-less');
    grunt.registerTask('default', ['less']);
    grunt.loadNpmTasks('grunt-contrib-connect');
};
