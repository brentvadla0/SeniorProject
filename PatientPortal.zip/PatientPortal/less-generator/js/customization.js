angular
//may need to create a factory block for the get request
//theme names will determine the drop down items and names
//clicking on each theme item will call a function to replace the forminfo values
    .module('customize', ['colorpicker.module'])

    .controller('custController', function($scope, $http) {

        $scope.formInfo = {
            primHeadCol: '',
            primBorCol: '',
            defHeadCol: '',
            defBorCol: '',
            toolBackCol: '',
            toolFrontCol: '',
            primBtnColBack: '',
            primBtnFrontCol: '',
            defBtnColBack: '',
            defBtnFrontCol: '',
            secBtnColBack: '',
            secBtnFrontCol: ''
        };

        //accept is difference from content-type
        $http.defaults.headers.common["ApiKey"] = 'C83BBF42-DA17-4F58-9AA0-68F417419313';
        $http.defaults.headers.common["Accept"] = 'application/json;charset=utf-8';

        ////
        $scope.data = [];
        var d = $http.get('https://aprod-sbt2.servicebus.windows.net/2267814F-63D1-4F59-8A5F-B4F270874E90/api/v1/utd/portal-themes');
        // var d = $http.get('test.json');
        d.then(function(result) {
            $scope.data = result.data;
            console.log($scope.data);
        });
        ////

        //we may need to assume that the theme will have 12 values
        //	in theme configurations part of JSON
        $scope.populateForm = function(object) {
            console.log(object);
        };


        // $scope.populateForm = function(object) {
        // 	$scope.formInfo.primHeadCol = object.ThemeConfigurations[0].Value;
        // 	$scope.formInfo.primBorCol = object.ThemeConfigurations[1].Value;
        // 	$scope.formInfo.defHeadCol = object.ThemeConfigurations[2].Value;
        // };


        $scope.saveData = function() {

            //import the less generator file at the bottom, and use the keyword "(optional)".
            //
            var lessText = "@bodyCol: " + $scope.formInfo.primHeadCol + ";\n"
                + "@primBorCol: " + $scope.formInfo.primBorCol + ";\n"
                + "@defHeadCol: " + $scope.formInfo.defHeadCol + ";\n"
                + "@defBorCol: " + $scope.formInfo.defBorCol + ";\n"
                + "@toolBackCol: " + $scope.formInfo.toolBackCol + ";\n"
                + "@toolFrontCol: " + $scope.formInfo.toolFrontCol + ";\n"
                + "@primBtnColBack: " + $scope.formInfo.primBtnColBack + ";\n"
                + "@primBtnFrontCol: " + $scope.formInfo.primBtnFrontCol + ";\n"
                + "@defBtnColBack: " + $scope.formInfo.defBtnColBack + ";\n"
                + "@defBtnFrontCol: " + $scope.formInfo.defBtnFrontCol + ";\n"
                + "@secBtnColBack: " + $scope.formInfo.secBtnColBack + ";\n"
                + "@secBtnFrontCol: " + $scope.formInfo.secBtnFrontCol + ";";
            var lessFile = new Blob([lessText], {type: "text/css;charset=utf-8"});
            saveAs(lessFile, "source.less");
        };
    });